import jsPDF from "jspdf";

export const generatePDF = () => {
  const doc = new jsPDF();
  doc.text("Application for Birth Certificate", 10, 10);
  doc.save("application.pdf");
};