export default function Home() {
  return (
    <div style={{padding:20}}>
      <h1>Bagula Birth Application</h1>
      <p>⏱ Takes 3–5 minutes</p>
      <p>Apply Once, Submit Once</p>
      <a href="/login">Start Application</a>
    </div>
  )
}