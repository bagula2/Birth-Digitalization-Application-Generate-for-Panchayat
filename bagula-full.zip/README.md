# Bagula Birth Certificate System
Mobile deployable via Vercel.
